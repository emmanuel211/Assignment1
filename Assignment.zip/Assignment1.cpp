#include<iostream>
#include<math.h>
using namespace std;

int main() {

	
//overflow
int y = 1.9*pow(10,19);
int f = +9.3*pow(10,18);

//underflow
int x = -9.3*pow(10,18);

// overflow
short a = 65537;
short g = +40000;

//underflow 
short b = -32770;

//overflow
char r = 700;
char v = +400;

//underflow
char s= -500;
}
